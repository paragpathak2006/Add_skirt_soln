#include "../../Header/IO/Parameters.h"
double Parameters::tolerence;
string Parameters::file;
string Parameters::type;
int Parameters::step;
double Parameters::slope;
double Parameters::min_angle;
double Parameters::sprawl;

